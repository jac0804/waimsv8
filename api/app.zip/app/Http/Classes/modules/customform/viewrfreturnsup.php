<?php

namespace App\Http\Classes\modules\customform;

use App\Http\Classes\builder\tabClass;
use App\Http\Classes\builder\txtfieldClass;
use App\Http\Classes\coreFunctions;
use App\Http\Classes\companysetup;
use App\Http\Classes\othersClass;
use App\Http\Classes\Logger;
use Exception;

class viewrfreturnsup
{
  private $fieldClass;
  private $tabClass;
  private $coreFunctions;
  private $companysetup;
  private $othersClass;
  private $warehousinglookup;

  public $modulename = 'Return to Supplier';
  public $gridname = 'tableentry';
  private $fields = [];
  private $table = 'rfhead';
  private $htable = 'hrfhead';

  public $tablelogs = 'table_log';

  public $style = 'width:100%;max-width:70%;';
  public $issearchshow = true;
  public $showclosebtn = true;

  public function __construct($params = null)
  {
    $this->fieldClass = new txtfieldClass($params);
    $this->tabClass = new tabClass($params);;
    $this->coreFunctions = new coreFunctions;
    $this->companysetup = new companysetup;
    $this->othersClass = new othersClass;
    $this->logger = new Logger;
  }

  public function getAttrib()
  {
    $attrib = array('load' => 0);
    return $attrib;
  }

  public function createHeadField($config)
  {
    $trno = $config['params']['clientid'];
    $doc = $config['params']['doc'];
    $isposted = $this->othersClass->isposted2($trno, "transnum");

    $qry = "
    select dateclose as value from rfhead where trno = ? 
    union all
    select dateclose as value from hrfhead where trno = ? 
    LIMIT 1";
    $check_dateclose = $this->coreFunctions->datareader($qry, [$trno, $trno]);


    $fields = [
      ['client', 'returndate_sup'],
      'clientname',
      ['lblshipping', ''],
      ['awb'],
      'action'
    ];

    if ($check_dateclose == "") {
      array_push($fields, ['refresh']);
    }

    $col1 = $this->fieldClass->create($fields);
    data_set($col1, 'refresh.label', 'Save');
    data_set($col1, 'client.label', 'Supplier Code');
    data_set($col1, 'clientname.label', 'Supplier Name');
    data_set($col1, 'client.lookupclass', 'rfsupplier');
    data_set($col1, 'lblshipping.label', 'Additional Details Supplier');
    data_set($col1, 'awb.type', 'cinput');
    data_set($col1, 'awb.maxlength', '30');
    data_set($col1, 'action.type', 'ctextarea');
    data_set($col1, 'action.maxlength', '200');

    if ($check_dateclose != "") {
      data_set($col1, 'refresh.label', 'Save');
      data_set($col1, 'returndate_sup.type', 'input');
      data_set($col1, 'returndate_cust.type', 'input');
      data_set($col1, 'returndate_sup.readonly', true);
      data_set($col1, 'returndate_cust.readonly', true);
      data_set($col1, 'returndate_supby.readonly', true);
      data_set($col1, 'returndate_custby.readonly', true);
      data_set($col1, 'awb.readonly', true);
      data_set($col1, 'dateclose.readonly', true);
      data_set($col1, 'action.readonly', true);
    }

    return array('col1' => $col1, 'col2' => []);
  }

  public function paramsdata($config)
  {
    return $this->getheaddata($config);
  }

  public function getheaddata($config)
  {
    $doc = $config['params']['doc'];
    $trno = $config['params']['clientid'];

    switch ($doc) {
      case 'RF':
        $tbl = strtolower($doc) . 'head';
        $htbl = 'h' . strtolower($doc) . 'head';
        break;
    }

    $select = "
    select ifnull(rf.trno, 0) as trno, ifnull(client.client,'') as client, ifnull(rf.supplierid,0) as clientid, 
    ifnull(client.clientname,'') as clientname,
    ifnull(date(returndate_sup),'') as returndate_sup, 
    ifnull(rf.returndate_supby, '') as returndate_supby,
    ifnull(rf.awb, '') as awb, ifnull(rf.action, '') as action, ifnull(date(dateclose),'') as dateclose";

    $qry = "" . $select . "
      from " . $tbl . " as rf
      left join client on client.clientid = rf.supplierid
      where rf.trno = ?
      union all
      " . $select . "
      from " . $htbl . "  as rf
      left join client on client.clientid = rf.supplierid
      where rf.trno = ?";

    $data = $this->coreFunctions->opentable($qry, [$trno, $trno]);

    if (empty($data)) {
      $data = $this->coreFunctions->opentable("
        select 
        '" . $trno . "' as trno, 
        '' as returndate_sup, 
        '' as returndate_supby, 
        '0' as clientid, 
        '' as clientname, 
        '' as awb, 
        '' as action, 
        '' as dateclose, 
        '' as client
        ");
    }
    return $data;
  }

  public function data()
  {
    return [];
  }

  public function createTab($config)
  {
    $tab = [];
    $stockbuttons = [];
    $obj = $this->tabClass->createtab($tab, $stockbuttons);
    return $obj;
  }

  public function createtabbutton($config)
  {
    $tbuttons = [];
    $obj = $this->tabClass->createtabbutton($tbuttons);

    return $obj;
  }

  public function loaddata($config)
  {
    $companyid = $config['params']['companyid'];
    $trno = $config['params']['dataparams']['trno'];
    $isposted = $this->othersClass->isposted2($trno, "transnum");
    $table = $isposted == false ? "rfhead" : "hrfhead";
    $msg = '';

    $qry = "
    select dateclose as value from rfhead where trno = ? 
    union all
    select dateclose as value from hrfhead where trno = ? 
    LIMIT 1";

    if ($this->coreFunctions->datareader($qry, [$trno, $trno])) {
      $config['params']['clientid'] = $trno;
      $txtdata = $this->paramsdata($config);
      return ['status' => false, 'msg' => 'Already close date', 'data' => [], 'txtdata' => $txtdata];
    }

    $dateTables = [$table];
    $lookups = $this->othersClass->buildSanitizeLookups($config['params']['doc'], $companyid, [], false, $dateTables);


    switch ($config['params']['action2']) {
      case 'close':


        $data = [
          'trno' => $trno,
          'dateclose' => $this->othersClass->sanitizekeyfieldFast('dateclose', $config['params']['dataparams']['dateclose'], $lookups),
        ];
        $msg = 'The transaction has been closed.';

        break;
      default:
        $data = [
          'trno' => $trno,
          'returndate_sup' => $this->othersClass->sanitizekeyfieldFast('returndate_sup', $config['params']['dataparams']['returndate_sup'], $lookups),
          'returndate_supby' => $config['params']['dataparams']['returndate_supby'],
          'supplierid' => $config['params']['dataparams']['clientid'],
          'awb' => $config['params']['dataparams']['awb'],
          'action' => $config['params']['dataparams']['action'],
        ];
        $msg = 'Successfully saved.';
        break;
    }

    $qry = "
    select trno as value 
    from rfhead where trno = ? 
    union all
    select trno as value 
    from hrfhead where trno = ? 
    LIMIT 1";
    $count = $this->coreFunctions->datareader($qry, [$trno, $trno]);



    if ($count != '') {
      $this->coreFunctions->sbcupdate($table, $data, ['trno' => $trno]);
    } else {
      $this->coreFunctions->insertGetId($table, $data);
    }

    $config['params']['clientid'] = $trno;
    $txtdata = $this->paramsdata($config);

    return ['status' => true, 'msg' => $msg, 'data' => [], 'txtdata' => $txtdata];
  }
}
