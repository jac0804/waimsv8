<?php

namespace App\Http\Classes\modules\accounting;

use Illuminate\Http\Request;
use App\Http\Requests;
use DB;
use Session;

use App\Http\Classes\builder\buttonClass;
use App\Http\Classes\builder\txtfieldClass;
use App\Http\Classes\builder\tabClass;
use App\Http\Classes\companysetup;
use App\Http\Classes\coreFunctions;
use App\Http\Classes\othersClass;
use App\Http\Classes\Logger;
use App\Http\Classes\sqlquery;
use App\Http\Classes\SBCPDF;
use App\Http\Classes\builder\helpClass;

class ds
{
  private $btnClass;
  private $fieldClass;
  private $tabClass;
  public $modulename = 'DEPOSIT SLIP';
  public $gridname = 'accounting';
  private $companysetup;
  private $coreFunctions;
  private $othersClass;
  private $logger;
  private $sqlquery;
  public $expirystatus = ['readonly' => false, 'show' => false, 'showdate' => true];
  public $tablenum = 'cntnum';
  public $head = 'lahead';
  public $hhead = 'glhead';
  public $detail = 'ladetail';
  public $hdetail = 'gldetail';
  public $tablelogs = 'table_log';
  public $htablelogs = 'htable_log';
  public $tablelogs_del = 'del_table_log';
  private $stockselect;
  public $defaultContra = 'CB1';

  private $fields = ['trno', 'docno', 'dateid', 'contra', 'yourref', 'ourref', 'rem', 'projectid', 'phaseid', 'modelid', 'blklotid', 'amenityid', 'subamenityid'];
  private $except = ['trno', 'dateid'];
  private $acctg = [];
  public $showfilteroption = true;
  public $showfilter = true;
  public $showcreatebtn = true;
  private $reporter;
  private $helpClass;

  public function __construct($params = null)
  {
    $this->btnClass = new buttonClass;
    $this->fieldClass = new txtfieldClass($params);
    $this->tabClass = new tabClass($params);;
    $this->companysetup = new companysetup;
    $this->coreFunctions = new coreFunctions;
    $this->othersClass = new othersClass;
    $this->logger = new Logger;
    $this->sqlquery = new sqlquery;
    $this->reporter = new SBCPDF;
    $this->helpClass = new helpClass;
  }

  public function getAttrib()
  {
    $attrib = array(
      'view' => 327,
      'edit' => 328,
      'new' => 329,
      'save' => 330,
      // 'change'=>331, remove change doc
      'delete' => 332,
      'print' => 333,
      'lock' => 334,
      'unlock' => 335,
      'post' => 336,
      'unpost' => 337,
      'additem' => 338,
      'edititem' => 339,
      'deleteitem' => 340
    );
    return $attrib;
  }

  public function createdoclisting($config)
  {
    $companyid = $config['params']['companyid'];
    // $action = 0;
    // $liststatus = 1;
    // $listdocument = 2;
    // $listdate = 3;
    // $listclientname = 4;
    // $yourref = 5;
    // $ourref = 6;
    // $db = 7;
    // $postdate = 8;

    if ($companyid == 29) { //sbc
      $getcols = ['action', 'liststatus', 'listdocument', 'listdate', 'acnoname', 'yourref', 'ourref', 'db', 'listpostedby', 'listcreateby', 'listeditby', 'listviewby'];
    } else {
      $getcols = ['action', 'liststatus', 'listdocument', 'listdate', 'listclientname', 'yourref', 'ourref', 'db', 'listpostedby', 'listcreateby', 'listeditby', 'listviewby'];
    }

    foreach ($getcols as $key => $value) {
      $$value = $key;
    }

    $stockbuttons = ['view'];
    $cols = $this->tabClass->createdoclisting($getcols, $stockbuttons);

    $cols[$action]['style'] = 'width:40px;whiteSpace: normal;min-width:40px;';
    $cols[$liststatus]['style'] = 'width:100px;whiteSpace: normal;min-width:100px;';
    $cols[$yourref]['align'] = 'text-left';
    $cols[$ourref]['align'] = 'text-left';
    // $cols[$postdate]['label'] = 'Posted By';

    switch ($companyid) {
      case 19: //housegem
        $cols[$listclientname]['style'] = 'width:200px;whiteSpace: normal;min-width:200px;';
        break;
      case 29: //sbc
        $cols[$db]['type'] = 'coldel';
        $cols[$acnoname]['label'] = 'Account Name';
        $cols[$acnoname]['type'] = 'label';
        $cols[$acnoname]['style'] = 'width:200px;whiteSpace: normal;min-width:200px;';
        break;
      default:
        $cols[$db]['type'] = 'coldel';
        $cols[$listclientname]['style'] = 'width:200px;whiteSpace: normal;min-width:200px;';
        break;
    }

    $cols = $this->tabClass->delcollisting($cols);
    return $cols;
  }

  public function loaddoclisting($config)
  {
    $date1 = date('Y-m-d', strtotime($config['params']['date1']));
    $date2 = date('Y-m-d', strtotime($config['params']['date2']));
    $itemfilter = $config['params']['itemfilter'];
    $doc = $config['params']['doc'];
    $center = $config['params']['center'];
    $condition = '';
    $searchfilter = $config['params']['search'];
    $limit = '';
    $ladb = '';
    $gldb = '';


    switch ($itemfilter) {
      case 'draft':
        $condition = ' and num.postdate is null ';
        break;
      case 'posted':
        $condition = ' and num.postdate is not null ';
        break;
    }

    $filtersearch = "";
    if (isset($config['params']['search'])) {
      $searchfield = ['head.docno', 'head.clientname', 'head.yourref', 'head.ourref', 'num.postedby', 'head.createby', 'head.editby', 'head.viewby'];
      $search = $config['params']['search'];
      if ($search != "") {
        $filtersearch = $this->othersClass->multisearch($searchfield, $search);
      }
    }

    $companyid = $config['params']['companyid'];
    switch ($companyid) {
      case 10: //afti
      case 12: //afti usd
        $dateid = "date_format(head.dateid,'%m-%d-%Y') as dateid";
        if ($searchfilter == "") $limit = 'limit 25';
        $orderby =  "order by  dateid desc, docno desc";
        $ladb = ", (select FORMAT(sum(d.db)," . $this->companysetup->getdecimal('currency', $config['params']) . ") 
        from ladetail as d left join coa on coa.acnoid = d.acnoid
         where d.trno= head.trno) as db ";
        $gldb = ", (select FORMAT(sum(d.db)," . $this->companysetup->getdecimal('currency', $config['params']) . ") 
        from gldetail as d left join coa on coa.acnoid = d.acnoid
         where d.trno= head.trno) as db ";
        break;
      case 19: //housegem
        $dateid = "left(head.dateid,10) as dateid";
        $ladb = ", (select FORMAT(sum(d.db)," . $this->companysetup->getdecimal('currency', $config['params']) . ") 
       from ladetail as d left join coa on coa.acnoid = d.acnoid
        where d.trno= head.trno) as db ";
        $gldb = ", (select FORMAT(sum(d.db)," . $this->companysetup->getdecimal('currency', $config['params']) . ") 
       from gldetail as d left join coa on coa.acnoid = d.acnoid
        where d.trno= head.trno) as db ";
        if ($searchfilter == "") $limit = 'limit 150';
        $orderby =  "order by docno desc, dateid desc";
        break;
      case 29: //sbc
        $dateid = "left(head.dateid,10) as dateid";
        if ($searchfilter == "") $limit = 'limit 150';
        $orderby =  "order by  dateid desc, docno desc";
        $ladb = ", (select coa.acnoname from ladetail as d 
                    left join coa on coa.acnoid = d.acnoid 
                    where d.trno= head.trno and left(coa.alias,2)='CB') as acnoname ";
        $gldb = ", (select coa.acnoname from gldetail as d 
                    left join coa on coa.acnoid = d.acnoid 
                    where d.trno= head.trno and left(coa.alias,2)='CB') as acnoname";
        break;
      default:
        $dateid = "left(head.dateid,10) as dateid";
        if ($searchfilter == "") $limit = 'limit 150';
        $orderby =  "order by  dateid desc, docno desc";
        break;
    }
    $qry = "select head.trno,head.docno,head.clientname,$dateid $ladb, 'DRAFT' as status,
    head.createby,head.editby,head.viewby,num.postedby,
      head.yourref, head.ourref              
     from " . $this->head . " as head left join " . $this->tablenum . " as num 
     on num.trno=head.trno where head.doc=? and num.center = ? and CONVERT(head.dateid,DATE)>=? and CONVERT(head.dateid,DATE)<=? " . $condition . " " . $filtersearch . "
     union all
     select head.trno,head.docno,head.clientname,$dateid $gldb,'POSTED' as status,
     head.createby,head.editby,head.viewby, num.postedby,
       head.yourref, head.ourref              
     from " . $this->hhead . " as head left join " . $this->tablenum . " as num 
     on num.trno=head.trno where head.doc=? and num.center = ? and CONVERT(head.dateid,DATE)>=? and CONVERT(head.dateid,DATE)<=? " . $condition . " " . $filtersearch . "
    $orderby $limit";
    //  var_dump($qry);
    $data = $this->coreFunctions->opentable($qry, [$doc, $center, $date1, $date2, $doc, $center, $date1, $date2]);
    return ['data' => $data, 'status' => true, 'msg' => 'Listing successfully loaded.'];
  }

  public function createHeadbutton($config)
  {
    $btns = array(
      'load',
      'new',
      'save',
      'delete',
      'cancel',
      'print',
      'lock',
      'unlock',
      'post',
      'unpost',
      'logs',
      'edit',
      'backlisting',
      'toggleup',
      'toggledown',
      'help',
      'others'
    );
    $buttons = $this->btnClass->create($btns);
    $step1 = $this->helpClass->getFields(['btnnew', 'dcontra', 'dateid', 'terms', 'yourref', 'csrem', 'btnsave']);
    $step2 = $this->helpClass->getFields(['btnedit', 'dcontra', 'dateid', 'terms', 'yourref', 'csrem', 'btnsave']);
    $step3 = $this->helpClass->getFields(['btnaddaccount', 'db', 'cr', 'rem', 'btnstocksaveaccount', 'btnsaveaccount']);
    $step4 = $this->helpClass->getFields(['db', 'cr', 'rem', 'btnstocksaveaccount', 'btnsaveaccount']);
    $step5 = $this->helpClass->getFields(['btnstockdeleteaccount', 'btndeleteallaccount']);
    $step6 = $this->helpClass->getFields(['btndelete']);


    $buttons['help']['items'] = [
      'create' => ['label' => 'How to create New Document', 'action' => $step1],
      'edit' => ['label' => 'How to edit details from the header', 'action' => $step2],
      'additem' => ['label' => 'How to add account/s', 'action' => $step3],
      'edititem' => ['label' => 'How to edit account details', 'action' => $step4],
      'deleteitem' => ['label' => 'How to delete account/s', 'action' => $step5],
      'deletehead' => ['label' => 'How to delete whole transaction', 'action' => $step6]
    ];


    $buttons['others']['items'] = [
      'first' => ['label' => 'First', 'todo' => ['action' => 'navigation', 'lookupclass' => 'first', 'access' => 'view', 'type' => 'navigation']],
      'prev' => ['label' => 'Previous', 'todo' => ['action' => 'navigation', 'lookupclass' => 'prev', 'access' => 'view', 'type' => 'navigation']],
      'next' => ['label' => 'Next', 'todo' => ['action' => 'navigation', 'lookupclass' => 'next', 'access' => 'view', 'type' => 'navigation']],
      'last' => ['label' => 'Last', 'todo' => ['action' => 'navigation', 'lookupclass' => 'last', 'access' => 'view', 'type' => 'navigation']],
    ];
    if ($this->companysetup->getisshowmanual($config['params'])) {
      $buttons['others']['items']['manual'] = ['label' => 'View Manual', 'todo' => ['lookupclass' => 'ds', 'title' => 'DS_MANUAL', 'action' => 'viewpdf',  'access' => 'view', 'type' => 'viewmanual']];
    }
    return $buttons;
  } // createHeadbutton


  public function createtab2($access, $config)
  {
    $tab = ['tableentry' => ['action' => 'documententry', 'lookupclass' => 'entrycntnumpicture', 'label' => 'Attachment', 'access' => 'view']];
    $obj = $this->tabClass->createtab($tab, []);

    $return['Attachment'] = ['icon' => 'fa fa-envelope', 'tab' => $obj];

    if ($this->companysetup->getistodo($config['params'])) {
      $tab = ['tableentry' => ['action' => 'tableentry', 'lookupclass' => 'entrycntnumtodo', 'label' => 'To Do', 'access' => 'view']];
      $objtodo = $this->tabClass->createtab($tab, []);
      $return['To Do'] = ['icon' => 'fa fa-list', 'tab' => $objtodo];
    }

    if ($config['params']['companyid'] == 60) { //transpower      
      $changecode = $this->othersClass->checkAccess($config['params']['user'], 5505);
      if ($changecode) {
        $changecode = ['customform' => ['action' => 'customform', 'lookupclass' => 'changebarcode']];
        $return['CHANGE CODE'] = ['icon' => 'fa fa-qrcode', 'customform' => $changecode];
      }
    }


    return $return;
  }

  public function createTab($access, $config)
  {
    $companyid = $config['params']['companyid'];
    $systype = $this->companysetup->getsystemtype($config['params']);

    $action = 0;
    $acno = 1;
    $acnoname = 2;
    $clientname = 3;
    $db = 4;
    $cr = 5;
    $postdate = 6;
    $checkno = 7;
    $rem = 8;
    $ref = 9;
    $acnoname = 10;

    $columns = [
      'action',
      'acno',
      'acnoname',
      'clientname',
      'db',
      'cr',
      'postdate',
      'checkno',
      'rem',
      'ref',
      'acnoname'
    ];

    switch ($systype) {
      case 'REALESTATE':
        $project = 11;
        $phasename = 12;
        $housemodel = 13;
        $blk = 14;
        $lot = 15;
        $amenityname = 16;
        $subamenityname = 17;
        array_push($columns, 'project', 'phasename', 'housemodel', 'blk', 'lot', 'amenityname', 'subamenityname');

        break;
    }

    $tab = [
      $this->gridname => [
        'gridcolumns' => $columns,
        'headgridbtns' => ['viewacctginfo', 'viewref', 'viewdiagram']
      ],
    ];

    $stockbuttons = ['save', 'delete'];
    if ($this->companysetup->getiseditsortline($config['params'])) {
      array_push($stockbuttons, 'sortline');
    }



    $obj = $this->tabClass->createtab($tab, $stockbuttons);

    $obj[0]['accounting']['columns'][$acno]['readonly'] = true;
    $obj[0]['accounting']['columns'][$acnoname]['readonly'] = true;
    $obj[0]['accounting']['columns'][$clientname]['readonly'] = true;
    $obj[0]['accounting']['columns'][$clientname]['label'] = 'Customer Name';
    $obj[0]['accounting']['columns'][$acno]['style'] = 'width:120px;whiteSpace: normal;min-width:120px;';
    $obj[0]['accounting']['columns'][$clientname]['style'] = 'width:150px;whiteSpace: normal;min-width:150px;';
    $obj[0]['accounting']['columns'][$postdate]['style'] = 'width:150px;whiteSpace: normal;min-width:150px;';
    $obj[0]['accounting']['columns'][$checkno]['style'] = 'width:400px;whiteSpace: normal;min-width:400px;';


    switch ($systype) {
      case 'REALESTATE':
        $obj[0]['accounting']['columns'][$blk]['readonly'] = true;
        $obj[0]['accounting']['columns'][$lot]['readonly'] = true;
        break;
    }

    if ($companyid == 60) { //transpower
      $obj[0]['accounting']['columns'][$rem]['style'] = 'text-align: left; width: 250px;whiteSpace: normal;min-width:250px;max-width:250px;';
      $obj[0]['accounting']['columns'][$rem]['type'] = 'textarea';
    }

    return $obj;
  }

  public function createtabbutton($config)
  {
    $tbuttons = ['projchecks', 'checks', 'additem', 'saveitem', 'deleteallitem'];

    if ($config['params']['companyid'] != 48) { //not seastar
      $tbuttons = ['checks', 'additem', 'saveitem', 'deleteallitem'];
    }

    foreach ($tbuttons as $key => $value) {
      $$value = $key;
    }

    $obj = $this->tabClass->createtabbutton($tbuttons);
    $obj[$additem]['label'] = "ADD ACCOUNT";
    $obj[$additem]['action'] = "adddetail";
    $obj[$saveitem]['label'] = "SAVE ACCOUNT";
    $obj[$deleteallitem]['label'] = "DELETE ACCOUNT";

    return $obj;
  }

  public function createHeadField($config)
  {
    $companyid = $config['params']['companyid'];
    $systype = $this->companysetup->getsystemtype($config['params']);
    $noeditdate = $this->othersClass->checkAccess($config['params']['user'], 4853);
    $fields = ['docno', 'dacnoname'];
    $col1 = $this->fieldClass->create($fields);
    data_set($col1, 'docno.label', 'Transaction#');
    data_set($col1, 'dacnoname.lookupclass', 'CB');

    $fields = ['dateid', 'dprojectname'];
    if ($systype == 'REALESTATE') {
      $fields = ['dateid', ['yourref', 'ourref'], 'rem'];
    }
    $col2 = $this->fieldClass->create($fields);

    if ($companyid == 40) { //cdo
      if ($noeditdate) {
        data_set($col2, 'dateid.class', 'sbccsreadonly');
      }
    }

    $fields = [['yourref', 'ourref'], 'rem'];
    if ($systype == 'REALESTATE') {
      $fields = ['dprojectname', 'phase', 'housemodel', ['blklot', 'lot'], 'amenityname', 'subamenityname'];
    }
    if ($this->companysetup->getistodo($config['params'])) {
      array_push($fields, 'donetodo');
    }
    $col3 = $this->fieldClass->create($fields);
    if ($systype == 'REALESTATE') {
      data_set($col3, 'dprojectname.lookupclass', 'project');
      data_set($col3, 'phase.addedparams', ['projectid']);
      data_set($col3, 'housemodel.addedparams', ['projectid']);
      data_set($col3, 'blklot.addedparams', ['projectid', 'phaseid', 'modelid', 'fpricesqm']);
      data_set($col3, 'subamenityname.addedparams', ['amenityid']);
    }

    if ($companyid == 21) { //kinggeorge
      data_set($col2, 'dprojectname.type', 'coldel');
    }
    if ($companyid == 26) { //bee healthy
      data_set($col2, 'dprojectname.label', 'Business Unit');
    }

    return array('col1' => $col1, 'col2' => $col2, 'col3' => $col3);
  }



  public function createnewtransaction($docno, $params)
  {
    $data = [];
    $data[0]['trno'] = 0;
    $data[0]['docno'] = $docno;
    $data[0]['dateid'] = $this->othersClass->getCurrentDate();
    $data[0]['client'] = '';
    $data[0]['clientname'] = '';
    $data[0]['yourref'] = '';
    $data[0]['ourref'] = '';
    $data[0]['rem'] = '';
    $data[0]['terms'] = '';
    $data[0]['forex'] = 1;
    $data[0]['cur'] = $this->companysetup->getdefaultcurrency($params);
    $data[0]['contra'] = $this->coreFunctions->getfieldvalue('coa', 'acno', 'alias=?', [$this->defaultContra]);
    $data[0]['acnoname'] = $this->coreFunctions->getfieldvalue('coa', 'acnoname', 'acno=?', [$data[0]['contra']]);
    $data[0]['projectid'] = 0;
    $data[0]['projectcode'] = '';
    $data[0]['projectname'] = '';

    $data[0]['phaseid'] = 0;
    $data[0]['phase'] = '';

    $data[0]['modelid'] = 0;
    $data[0]['housemodel'] = '';

    $data[0]['blklotid'] = 0;
    $data[0]['blklot'] = '';
    $data[0]['lot'] = '';

    $data[0]['amenityid'] = 0;
    $data[0]['amenityname'] = '';

    $data[0]['subamenityid'] = 0;
    $data[0]['subamenityname'] = '';
    return $data;
  }

  public function loadheaddata($config)
  {
    $doc = $config['params']['doc'];
    $trno = $config['params']['trno'];
    $center = $config['params']['center'];
    $tablenum = $this->tablenum;
    if ($trno == 0) {
      $trno = $this->othersClass->readprofile('TRNO', $config);
      if ($trno == '') {
        $trno = $this->coreFunctions->datareader("select trno as value from " . $this->tablenum . " where doc=? and center=? order by trno desc limit 1", [$doc, $center]);
      }
      $config['params']['trno'] = $trno;
    } else {
      $this->othersClass->checkprofile('TRNO', $trno, $config);
    }
    $center = $config['params']['center'];

    if ($this->companysetup->getistodo($config['params'])) {
      $this->othersClass->checkseendate($config, $tablenum);
    }

    $head = [];
    $islocked = $this->othersClass->islocked($config);
    $isposted = $this->othersClass->isposted($config);
    $table = $this->head;
    $htable = $this->hhead;

    $qryselect = "select 
        num.center,
        head.trno, 
        head.docno,
        client.client,
        head.terms,
        head.cur,
        head.forex,
        head.yourref,
        head.ourref,
        head.contra,
        coa.acnoname,
        '' as dacnoname,
        left(head.dateid,10) as dateid, 
        head.clientname,
        head.address, 
        head.shipto, 
        date_format(head.createdate,'%Y-%m-%d') as createdate,
        head.rem,
        head.project,
        ifnull(project.name,'') as projectname,
        '' as dprojectname,
        client.groupid,
        head.projectid,ifnull(project.code,'') as projectcode,
        ifnull(project.name,'') as projectname,
        '' as dprojectname,
         
        head.phaseid, 
        ph.code as phase,

        head.modelid, 
        hm.model as housemodel, 
        
        head.blklotid, 
        bl.blk as blklot, 
        bl.lot,
        
        amh.line as amenityid,
        amh.description as amenityname,
        subamh.line as subamenityid,
        subamh.description as subamenityname ";

    $qry = $qryselect . " from $table as head
        left join $tablenum as num on num.trno = head.trno
        left join client on head.client = client.client
        left join coa on coa.acno=head.contra
        left join projectmasterfile as project on project.line=head.projectid
        
        left join phase as ph on ph.line = head.phaseid
        left join housemodel as hm on hm.line = head.modelid
        left join blklot as bl on bl.line = head.blklotid

        left join amenities as amh on amh.line= head.amenityid
        left join subamenities as subamh on subamh.line=head.subamenityid and subamh.amenityid=head.amenityid

        where head.trno = ? and num.doc=? and num.center = ? 
        union all " . $qryselect . " from $htable as head
        left join $tablenum as num on num.trno = head.trno
        left join client on head.clientid = client.clientid
        left join coa on coa.acno=head.contra 
        left join projectmasterfile as project on project.line=head.projectid 
        
        left join phase as ph on ph.line = head.phaseid
        left join housemodel as hm on hm.line = head.modelid
        left join blklot as bl on bl.line = head.blklotid

        left join amenities as amh on amh.line= head.amenityid
        left join subamenities as subamh on subamh.line=head.subamenityid and subamh.amenityid=head.amenityid

        where head.trno = ? and num.doc=? and num.center=? ";

    $head = $this->coreFunctions->opentable($qry, [$trno, $doc, $center, $trno, $doc, $center]);
    if (!empty($head)) {
      $detail = $this->opendetail($trno, $config);
      $viewdate = $this->othersClass->getCurrentTimeStamp();
      $viewby = $config['params']['user'];
      $this->coreFunctions->sbcupdate($this->head, ['viewdate' => $viewdate, 'viewby' => $viewby], ['trno' => $trno]);
      $msg = 'Data Fetched Success';
      if (isset($config['msg'])) {
        $msg = $config['msg'];
      }
      $hideobj = [];
      if ($this->companysetup->getistodo($config['params'])) {
        $btndonetodo = $this->othersClass->checkdonetodo($config, $tablenum);
        $hideobj = ['donetodo' => !$btndonetodo];
      }
      return  ['head' => $head, 'griddata' => ['accounting' => $detail], 'islocked' => $islocked, 'isposted' => $isposted, 'isnew' => false, 'status' => true, 'msg' => $msg, 'hideobj' => $hideobj];
    } else {
      $head[0]['trno'] = 0;
      $head[0]['docno'] = '';
      return ['status' => false, 'isnew' => true, 'head' => $head, 'griddata' => ['accounting' => []], 'msg' => 'Data Head Fetched Failed, either somebody already deleted the transaction or modified...'];
    }
  }


  public function updatehead($config, $isupdate)
  {
    $head = $config['params']['head'];
    $companyid = $config['params']['companyid'];
    $data = [];
    if ($isupdate) {
      unset($this->fields[1]);
      unset($head['docno']);
    }

    $dateTables = ['lahead'];
    $lookups = $this->othersClass->buildSanitizeLookups($config['params']['doc'], $companyid, [], false, $dateTables);


    foreach ($this->fields as $key) {
      if (array_key_exists($key, $head)) {
        $data[$key] = $head[$key];
        if (!in_array($key, $this->except)) {
          $data[$key] = $this->othersClass->sanitizekeyfieldFast($key, $data[$key], $lookups);
        } //end if    
      }
    }
    $data['editdate'] = $this->othersClass->getCurrentTimeStamp();
    $data['editby'] = $config['params']['user'];
    if ($isupdate) {
      $this->coreFunctions->sbcupdate($this->head, $data, ['trno' => $head['trno']]);
    } else {
      $data['doc'] = $config['params']['doc'];
      $data['createdate'] = $this->othersClass->getCurrentTimeStamp();
      $data['createby'] = $config['params']['user'];
      $this->coreFunctions->sbcinsert($this->head, $data);
      $this->logger->sbcwritelog($head['trno'], $config, 'CREATE', $head['docno'] . ' - ' . $head['client'] . ' - ' . $head['clientname']);
    }
  } // end function


  public function deletetrans($config)
  {
    $trno = $config['params']['trno'];
    $doc = $config['params']['doc'];
    $table = $config['docmodule']->tablenum;
    $docno = $this->coreFunctions->datareader("select docno as value from " . $table . ' where trno=?', [$trno]);
    $qry = "select trno as value from " . $this->tablenum . " where doc=? and trno<? order by trno desc limit 1 ";
    $trno2 = $this->coreFunctions->datareader($qry, [$doc, $trno]);
    $this->deleteallitem($config);
    $this->coreFunctions->execqry('delete from ' . $this->head . " where trno=?", 'delete', [$trno]);
    $this->coreFunctions->execqry('delete from ' . $this->tablenum . " where trno=?", 'delete', [$trno]);
    $this->othersClass->deleteattachments($config);
    $this->logger->sbcdel_log($trno, $config, $docno);
    return ['trno' => $trno2, 'status' => true, 'msg' => 'Successfully deleted.'];
  } //end function

  public function posttrans($config)
  {
    return $this->othersClass->posttransacctg($config);
  } //end function

  public function unposttrans($config)
  {
    return $this->othersClass->unposttransacctg($config);
  } //end function


  private function getdetailselect($config)
  {
    $qry = " 
      head.trno,left(head.dateid,10) as dateid,d.ref,d.line,d.sortline,coa.acno,coa.acnoname,
      client.client,client.clientname,d.rem,
      FORMAT(d.db,2) as db,FORMAT(d.cr,2) as cr,d.fdb,d.fcr,d.refx,d.linex,
      left(d.postdate,10) as postdate,d.checkno,coa.alias,d.pdcline,
      d.project,ifnull(proj.name,'') as projectname,d.cur,d.forex,
      case d.isewt when 0 then 'false' else 'true' end as isewt,case d.isvat when 0 then 'false' else 'true' end as isvat,case d.isvewt when 0 then 'false' else 'true' end as isvewt,d.ewtcode,d.ewtrate,d.damt,'' as bgcolor,'' as 
      errcolor,
  
      d.phaseid, ph.code as phasename,

      d.modelid, hm.model as housemodel, 

      d.blklotid, bl.blk, bl.lot,
      
      am.line as amenity,
      am.description as amenityname,
      subam.line as subamenity,
      subam.description as subamenityname ";

    return $qry;
  }


  public function opendetail($trno, $config)
  {
    $sqlselect = $this->getdetailselect($config);

    $qry = "select " . $sqlselect . " 
    from " . $this->detail . " as d
    left join " . $this->head . " as head on head.trno=d.trno
    left join client on client.client=d.client
    left join projectmasterfile as proj on proj.line = d.projectid
    
    left join phase as ph on ph.line = d.phaseid
    left join housemodel as hm on hm.line = d.modelid
    left join blklot as bl on bl.line = d.blklotid
    left join amenities as am on am.line= d.amenityid
    left join subamenities as subam on subam.line=d.subamenityid and subam.amenityid=d.amenityid

    left join coa on d.acnoid=coa.acnoid
    where d.trno=?
    union all
    select " . $sqlselect . "  
    from " . $this->hdetail . " as d
    left join " . $this->hhead . " as head on head.trno=d.trno
    left join client on client.clientid=d.clientid
    left join projectmasterfile as proj on proj.line = d.projectid
    
    left join phase as ph on ph.line = d.phaseid
    left join housemodel as hm on hm.line = d.modelid
    left join blklot as bl on bl.line = d.blklotid
    left join amenities as am on am.line= d.amenityid
    left join subamenities as subam on subam.line=d.subamenityid and subam.amenityid=d.amenityid

    left join coa on coa.acnoid=d.acnoid
    where d.trno=? order by sortline,line
  ";
    $detail = $this->coreFunctions->opentable($qry, [$trno, $trno]);
    return $detail;
  }


  public function opendetailline($config)
  {
    $sqlselect = $this->getdetailselect($config);
    $trno = $config['params']['trno'];
    $line = $config['params']['line'];
    $qry = "select " . $sqlselect . " 
    from " . $this->detail . " as d
    left join " . $this->head . " as head on head.trno=d.trno
    left join client on client.client=d.client
    left join projectmasterfile as proj on proj.line = d.projectid
    
    left join phase as ph on ph.line = d.phaseid
    left join housemodel as hm on hm.line = d.modelid
    left join blklot as bl on bl.line = d.blklotid
    left join amenities as am on am.line= d.amenityid
    left join subamenities as subam on subam.line=d.subamenityid and subam.amenityid=d.amenityid

    left join coa on d.acnoid=coa.acnoid
    where d.trno=? and d.line=?";

    $detail = $this->coreFunctions->opentable($qry, [$trno, $line]);
    return $detail;
  } // end function

  public function stockstatus($config)
  {
    switch ($config['params']['action']) {
      case 'adddetail':
        return $this->additem('insert', $config);
        break;
      case 'addallitem':
        return $this->addallitem($config);
        break;
      case 'deleteallitem':
        return $this->deleteallitem($config);
        break;
      case 'deleteitem':
        return $this->deleteitem($config);
        break;
      case 'saveitem': //save all detail edited
        return $this->updateitem($config);
        break;
      case 'saveperitem':
        return $this->updateperitem($config);
        break;
      case 'getcheckselected':
        return $this->getcheckselected($config);
        break;
      case 'getprojcheckselected':
        return $this->getprojcheckselected($config);
        break;
      default:
        return ['status' => 'false', 'msg' => 'Please check stockstatus (' . $config['params']['action'] . ')'];
        break;
    }
  }

  public function updateperitem($config)
  {
    $config['params']['data'] = $config['params']['row'];
    $isupdate = $this->additem('update', $config);
    $data = $this->opendetailline($config);
    if (!$isupdate) {
      $data[0]->errcolor = 'bg-red-2';
      return ['row' => $data, 'status' => true, 'msg' => 'Payment amount is greater than setup amount.'];
    } else {
      return ['row' => $data, 'status' => true, 'msg' => 'Successfully saved.'];
    }
  }


  public function updateitem($config)
  {
    foreach ($config['params']['row'] as $key => $value) {
      $config['params']['data'] = $value;
      $isupdate = $this->additem('update', $config);
      if ($isupdate['status'] == false) {
        break;
      }
    }
    $data = $this->opendetail($config['params']['trno'], $config);
    $data2 = json_decode(json_encode($data), true);
    //$isupdate = true;
    $msg1 = '';
    $msg2 = '';
    foreach ($data2 as $key => $value) {
      if ($data2[$key]['db'] == 0 && $data2[$key]['cr'] == 0) {
        $data[$key]->errcolor = 'bg-red-2';
        $isupdate = false;
        if ($data[$key]->refx == 0) {
          $msg1 = ' Some entries have zero value both debit and credit.';
        } else {
          $msg2 = ' Reference Amount is lower than encoded amount.';
        }
      }
    }
    if ($isupdate['status']) {
      return ['accounting' => $data, 'status' => true, 'msg' => 'Successfully saved.'];
    } else {
      if ($isupdate['msg'] == '') {
        return ['accounting' => $data, 'status' => true, 'msg' => 'Please check, some items have zero qty (' . $msg1 . ' / ' . $msg2 . ')'];
      } else {
        return ['accounting' => $data, 'status' => $isupdate['status'], 'msg' => $isupdate['msg']];
      }
    }
  } //end function

  public function addallitem($config)
  {
    foreach ($config['params']['row'] as $key => $value) {
      $config['params']['data'] = $value;
      $this->additem('insert', $config);
    }
    $data = $this->opendetail($config['params']['trno'], $config);
    return ['accounting' => $data, 'status' => true, 'msg' => 'Successfully saved.'];
  } //end function


  // insert and update detail
  public function additem($action, $config)
  {
    $systype = $this->companysetup->getsystemtype($config['params']);

    $acno = $config['params']['data']['acno'];
    $acnoname = $config['params']['data']['acnoname'];
    $trno = $config['params']['trno'];
    $db = $config['params']['data']['db'];
    $cr = $config['params']['data']['cr'];
    $postdate = $config['params']['data']['postdate'];
    $rem = $config['params']['data']['rem'];
    $project = '';
    $client = $config['params']['data']['client'];
    $companyid = $config['params']['companyid'];
    $refx = 0;
    $linex = 0;
    $ref = '';
    $checkno = '';
    $damt = 0;

    $projectid = 0;
    $phaseid = 0;
    $modelid = 0;
    $blklotid = 0;
    $amenityid = 0;
    $subamenityid = 0;

    if (isset($config['params']['data']['refx'])) {
      $refx = $config['params']['data']['refx'];
    }
    if (isset($config['params']['data']['linex'])) {
      $linex = $config['params']['data']['linex'];
    }
    if (isset($config['params']['data']['ref'])) {
      $ref = $config['params']['data']['ref'];
    }
    if (isset($config['params']['data']['checkno'])) {
      $checkno = $config['params']['data']['checkno'];
    }


    if ($systype == 'REALESTATE') {

      if (isset($config['params']['data']['projectid'])) {
        $projectid = $config['params']['data']['projectid'];
      }
      if (isset($config['params']['data']['phaseid'])) {
        $phaseid = $config['params']['data']['phaseid'];
      }
      if (isset($config['params']['data']['modelid'])) {
        $modelid = $config['params']['data']['modelid'];
      }
      if (isset($config['params']['data']['blklotid'])) {
        $blklotid = $config['params']['data']['blklotid'];
      }
      if (isset($config['params']['data']['amenityid'])) {
        $amenityid = $config['params']['data']['amenityid'];
      }
      if (isset($config['params']['data']['subamenityid'])) {
        $subamenityid = $config['params']['data']['subamenityid'];
      }

      if ($projectid == 0) {
        $projectid = $this->coreFunctions->getfieldvalue($this->head, "projectid", "trno=?", [$trno]);
      }
      if ($phaseid == 0) {
        $phaseid = $this->coreFunctions->getfieldvalue($this->head, "phaseid", "trno=?", [$trno]);
      }
      if ($modelid == 0) {
        $modelid = $this->coreFunctions->getfieldvalue($this->head, "modelid", "trno=?", [$trno]);
      }
      if ($blklotid == 0) {
        $blklotid = $this->coreFunctions->getfieldvalue($this->head, "blklotid", "trno=?", [$trno]);
      }
      if ($amenityid == 0) {
        $amenityid = $this->coreFunctions->getfieldvalue($this->head, "amenityid", "trno=?", [$trno]);
      }
      if ($subamenityid == 0) {
        $subamenityid = $this->coreFunctions->getfieldvalue($this->head, "subamenityid", "trno=?", [$trno]);
      }
    }


    $line = 0;
    if ($action == 'insert') {
      $qry = "select line as value from " . $this->detail . " where trno=? order by line desc limit 1";
      $line = $this->coreFunctions->datareader($qry, [$trno]);
      if ($line == '') {
        $line = 0;
      }


      $line = $line + 1;
      $config['params']['line'] = $line;
      if ($db != 0) {
        $damt = $db;
      } else {
        $damt = $cr;
      }
    } elseif ($action == 'update') {
      $config['params']['line'] = $config['params']['data']['line'];
      $line = $config['params']['data']['line'];
      $config['params']['line'] = $line;

      if ($db != 0) {
        $ddb = $this->coreFunctions->getfieldvalue($this->detail, 'db', 'trno=? and line =?', [$trno, $line]);

        if ($db != number_format($ddb, 2)) {
          $damt = $db;
        } else {
          $damt = $config['params']['data']['damt'];
        }
      } else {
        $dcr = $this->coreFunctions->getfieldvalue($this->detail, 'cr', 'trno=? and line =?', [$trno, $line]);
        if ($cr != number_format($dcr, 2)) {
          $damt = $cr;
        } else {
          $damt = $config['params']['data']['damt'];
        }
      }
    }
    $acnoid = $this->coreFunctions->getfieldvalue('coa', 'acnoid', 'acno=?', [$acno]);
    $data = [
      'trno' => $trno,
      'line' => $line,
      'acnoid' => $acnoid,
      'client' => $client,
      'db' => $db,
      'cr' => $cr,
      'postdate' => $postdate,
      'rem' => $rem,
      'project' => $project,
      'refx' => $refx,
      'linex' => $linex,
      'ref' => $ref,
      'checkno' => $checkno,
      'damt' => $damt,

    ];


    if ($systype == 'REALESTATE') {
      $data['projectid'] = $projectid;
      $data['phaseid'] = $phaseid;
      $data['modelid'] = $modelid;
      $data['blklotid'] = $blklotid;
      $data['amenityid'] = $amenityid;
      $data['subamenityid'] = $subamenityid;
    }

    $dateTables = ['ladetail'];
    $lookups = $this->othersClass->buildSanitizeLookups($config['params']['doc'], $companyid, [], false, $dateTables);

    foreach ($data as $key => $value) {
      $data[$key] = $this->othersClass->sanitizekeyfieldFast($key, $data[$key], $lookups);
    }

    $current_timestamp = $this->othersClass->getCurrentTimeStamp();
    $data['editdate'] = $current_timestamp;
    $data['editby'] = $config['params']['user'];
    $msg = '';

    if ($action == 'insert') {
      $data['encodedby'] = $config['params']['user'];
      $data['encodeddate'] = $current_timestamp;

      $data['sortline'] =  $data['line'];

      if ($this->coreFunctions->sbcinsert($this->detail, $data) == 1) {
        $msg = 'Account was successfully added.';
        $this->logger->sbcwritelog($trno, $config, 'ACCTG', 'ADD - Line:' . $line . ' Code:' . $acno . ' db:' . $db . ' cr:' . $cr . ' client:' . $client . ' date:' . $postdate . ' Refx:' . $refx . ' Linex:' . $linex);
        if ($refx != 0) {
          if (!$this->sqlquery->setupdatebal($refx, $linex, $acno, $config)) {
            $this->coreFunctions->sbcupdate($this->detail, ['db' => 0, 'cr' => 0, 'fdb' => 0, 'fcr' => 0], ['trno' => $trno, 'line' => $line]);
            $this->sqlquery->setupdatebal($refx, $linex, $acno, $config);
            $msg = "Payment Amount is greater than Amount Setup";
          }
        }
        $row = $this->opendetailline($config);
        return ['row' => $row, 'status' => true, 'msg' => $msg];
      } else {
        return ['status' => false, 'msg' => 'Add Account Failed'];
      }
    } elseif ($action == 'update') {
      $return = true;
      if ($this->coreFunctions->sbcupdate($this->detail, $data, ['trno' => $trno, 'line' => $line]) == 1) {
        if ($refx != 0) {
          if (!$this->sqlquery->setupdatebal($refx, $linex, $acno, $config)) {
            $this->coreFunctions->sbcupdate($this->detail, ['db' => 0, 'cr' => 0, 'fdb' => 0, 'fcr' => 0], ['trno' => $trno, 'line' => $line]);
            $this->sqlquery->setupdatebal($refx, $linex, $acno, $config, 1);
            $return = false;
          }
        }
      } else {
        $return = false;
      }
      return ['status' => $return, 'msg' => ''];
    }
  } // end function

  public function deleteallitem($config)
  {
    $trno = $config['params']['trno'];
    $data = $this->coreFunctions->opentable('select coa.acno,t.refx,t.linex from ' . $this->detail . ' as t left join coa on coa.acnoid=t.acnoid where t.trno=? and t.refx<>0', [$trno]);

    $this->coreFunctions->execqry('delete from ' . $this->detail . ' where trno=?', 'delete', [$trno]);
    foreach ($data as $key => $value) {
      $this->sqlquery->setupdatebal($data[$key]->refx, $data[$key]->linex, $data[$key]->acno, $config, 1);
    }
    $this->logger->sbcwritelog($trno, $config, 'ACCTG', 'DELETED ALL ACCTG ENTRIES');
    return ['status' => true, 'msg' => 'Successfully deleted.', 'accounting' => []];
  }



  public function deleteitem($config)
  {
    $config['params']['trno'] = $config['params']['row']['trno'];
    $config['params']['line'] = $config['params']['row']['line'];
    $data = $this->opendetailline($config);
    $trno = $config['params']['trno'];
    $line = $config['params']['line'];
    $qry = "delete from " . $this->detail . " where trno=? and line=?";
    $this->coreFunctions->execqry($qry, 'delete', [$trno, $line]);
    if ($data[0]->refx != 0) {
      $this->sqlquery->setupdatebal($data[0]->refx, $data[0]->linex, $data[0]->acno, $config, 1);
    }
    $data = json_decode(json_encode($data), true);
    $this->logger->sbcwritelog(
      $trno,
      $config,
      'DETAILINFO',
      'DELETE - Line:' . $line
        . ' Notes:' . $config['params']['row']['rem']
    );
    $this->logger->sbcwritelog($trno, $config, 'ACCTG', 'REMOVED - Line:' . $line . ' code:' . $data[0]['acno'] . ' db:' . $data[0]['db'] . ' cr:' . $data[0]['cr'] . ' client:' . $data[0]['client'] . ' date:' . $data[0]['postdate'] . ' ref:' . $data[0]['ref'] . ' Refx:' . $data[0]['refx'] . ' Linex:' . $data[0]['linex']);
    return ['status' => true, 'msg' => 'Account was successfully deleted.'];
  } // end function

  public function getcheckselected($config)
  {
    $systype = $this->companysetup->getsystemtype($config['params']);
    $trno = $config['params']['trno'];
    $rows = [];
    $data = $config['params']['rows'];
    foreach ($data as $key => $value) {
      $config['params']['data']['acno'] = $data[$key]['acno'];
      $config['params']['data']['acnoname'] = $data[$key]['acnoname'];
      if ($data[$key]['db'] != 0) {
        $config['params']['data']['db'] = 0;
        $config['params']['data']['cr'] = $data[$key]['db'];
      } else {
        $config['params']['data']['db'] = $data[$key]['cr'];
        $config['params']['data']['cr'] = 0;
      }
      $config['params']['data']['postdate'] = $data[$key]['checkdate'];
      $config['params']['data']['rem'] = '';
      $config['params']['data']['project'] = $data[$key]['costcenter'];
      $config['params']['data']['client'] = $data[$key]['client'];
      $config['params']['data']['refx'] = $data[$key]['trno'];
      $config['params']['data']['linex'] = $data[$key]['line'];
      $config['params']['data']['ref'] = $data[$key]['docno'];
      $config['params']['data']['checkno'] = $data[$key]['checkno'];
      $config['params']['data']['yourref'] = $data[$key]['yourref'];

      if ($systype == 'REALESTATE') {

        $config['params']['data']['projectid'] = $data[$key]['projectid'];
        $config['params']['data']['phaseid'] = $data[$key]['phaseid'];
        $config['params']['data']['modelid'] = $data[$key]['modelid'];
        $config['params']['data']['blklotid'] = $data[$key]['blklotid'];
        $config['params']['data']['amenityid'] = $data[$key]['amenityid'];
        $config['params']['data']['subamenityid'] = $data[$key]['subamenityid'];
      }

      $return = $this->additem('insert', $config);
      if ($return['status']) {
        array_push($rows, $return['row'][0]);
      }
    } //end foreach


    if ($config['params']['companyid'] != 11) { //not summit
      $auto = $this->autoentry($config);
      if ($auto['status']) {
        array_push($rows, $auto['row']);
      }
    }

    $this->loadheaddata($config);
    return ['row' => $rows, 'status' => true, 'msg' => 'Account was successfully added.', 'reloadhead' => true];
  } //end function

  public function getprojcheckselected($config)
  {
    $systype = $this->companysetup->getsystemtype($config['params']);

    $trno = $config['params']['trno'];
    $rows = [];
    $data = $config['params']['rows'];
    foreach ($data as $key => $value) {
      $config['params']['data']['acno'] = $data[$key]['acno'];
      $config['params']['data']['acnoname'] = $data[$key]['acnoname'];
      if ($data[$key]['db'] != 0) {
        $config['params']['data']['db'] = 0;
        $config['params']['data']['cr'] = $data[$key]['db'];
      } else {
        $config['params']['data']['db'] = $data[$key]['cr'];
        $config['params']['data']['cr'] = 0;
      }
      $config['params']['data']['postdate'] = $data[$key]['checkdate'];
      $config['params']['data']['rem'] = '';
      $config['params']['data']['project'] = $data[$key]['costcenter'];
      $config['params']['data']['client'] = $data[$key]['client'];
      $config['params']['data']['refx'] = $data[$key]['trno'];
      $config['params']['data']['linex'] = $data[$key]['line'];
      $config['params']['data']['ref'] = $data[$key]['docno'];
      $config['params']['data']['checkno'] = $data[$key]['checkno'];
      $config['params']['data']['yourref'] = $data[$key]['yourref'];

      $return = $this->additem('insert', $config);
      if ($return['status']) {
        array_push($rows, $return['row'][0]);
      }
    } //end foreach

    $auto = $this->autoentry($config);
    if ($auto['status']) {
      array_push($rows, $auto['row']);
    }

    return ['row' => $rows, 'status' => true, 'msg' => 'Account was successfully added.'];
  } //end function

  public function autoentry($config)
  {
    $trno = $config['params']['trno'];
    $companyid = $config['params']['companyid'];
    $rows = [];

    $contra = $this->coreFunctions->getfieldvalue($this->head, 'contra', 'trno=?', [$trno]);
    $dateid = $this->coreFunctions->getfieldvalue($this->head, 'dateid', 'trno=?', [$trno]);
    $project = $this->coreFunctions->getfieldvalue($this->head, 'project', 'trno=?', [$trno]);
    $acnoid = $this->coreFunctions->getfieldvalue("coa", 'acnoid', 'acno=?', [$contra]);

    $lastclient = '';
    if ($companyid == 68) {
      $lastclient = $this->coreFunctions->datareader("select client as value from " . $this->detail . " where trno=" . $trno . " and cr<>0 order by line desc limit 1");
    }

    $qry = "delete from " . $this->detail . " where trno=? and acnoid=?";
    $this->coreFunctions->execqry($qry, 'delete', [$trno, $acnoid]);

    $contraname = $this->coreFunctions->getfieldvalue('coa', 'acnoname', 'acno=?', [$contra]);
    $dbval = $this->coreFunctions->getfieldvalue($this->detail, 'sum(db-cr)', 'trno=?', [$trno]);

    if ($dbval != 0) {
      $config['params']['data']['acno'] = $contra;
      $config['params']['data']['acnoname'] = $contraname;

      if ($dbval < 0) {
        $config['params']['data']['db'] = $dbval * -1;
        $config['params']['data']['cr'] = 0;
      } else {
        $config['params']['data']['db'] = 0;
        $config['params']['data']['cr'] = $dbval;
      }

      $config['params']['data']['postdate'] = $dateid;
      $config['params']['data']['project'] = $project;
      $config['params']['data']['rem'] = 'AUTO-ENTRY';
      $config['params']['data']['client'] = $lastclient;
      $config['params']['data']['ref'] = '';
      $config['params']['data']['refx'] = 0;
      $config['params']['data']['linex'] = 0;

      $return = $this->additem('insert', $config);
      if ($return['status']) {
        $rows = $return['row'][0];
      }
    }

    return ['row' => $rows, 'status' => true, 'msg' => 'Account was successfully added.'];
  }

  public function stockstatusposted($config)
  {
    switch ($config['params']['action']) {
      case 'diagram':
        return $this->diagram($config);
        break;
      case 'navigation':
        return $this->othersClass->navigatedocno($config);
        break;
      case 'donetodo':
        $tablenum = $this->tablenum;
        return $this->othersClass->donetodo($config, $tablenum);
        break;
      default:
        return ['status' => 'false', 'msg' => 'Please check stockstatusposted (' . $config['params']['action'] . ')'];
        break;
    }
  }

  public function diagram($config)
  {
    $data = [];
    $nodes = [];
    $links = [];
    $data['width'] = 1500;
    $startx = 100;

    //GD
    $gjqry = "
    select  head.docno, date(head.dateid) as dateid, head.trno,
    CAST(concat('Applied Amount: ', round(detail.db+detail.cr,2)) as CHAR) as rem, detail.refx
    from glhead as head
    left join gldetail as detail on head.trno = detail.trno
    where head.trno = ? and detail.refx <> 0";
    $gjdata = $this->coreFunctions->opentable($gjqry, [$config['params']['trno']]);
    if (!empty($gjdata)) {
      $startx = 550;
      $starty = 100;
      $a = 0;
      foreach ($gjdata as $key2 => $value2) {
        data_set(
          $nodes,
          $gjdata[$key2]->docno . $gjdata[$key2]->refx,
          [
            'align' => 'left',
            'x' => $startx + 400,
            'y' => $starty,
            'w' => 250,
            'h' => 80,
            'type' => $gjdata[$key2]->docno,
            'label' => $gjdata[$key2]->rem,
            'color' => 'red',
            'details' => [$gjdata[$key2]->dateid]
          ]
        );
        $starty += 100;
        array_push($links, ['from' => 'gj', 'to' => 'paya_recei']);

        $qry = "
        select  head.docno, date(head.dateid) as dateid, head.trno,
        CAST(concat('Applied Amount: ', round(detail.db+detail.cr,2)) as CHAR) as rem, detail.refx
        from glhead as head
        left join gldetail as detail on head.trno = detail.trno
        where head.trno = ?";
        $t = $this->coreFunctions->opentable($qry, [$gjdata[$key2]->refx]);
        $startyyy = 100;
        if (!empty($t)) {
          foreach ($t as $key => $value) {
            data_set(
              $nodes,
              $t[$key]->docno,
              [
                'align' => 'left',
                'x' => $startx,
                'y' => $starty - 100,
                'w' => 250,
                'h' => 80,
                'type' => $t[$key]->docno,
                'label' => $t[$key]->rem,
                'color' => 'green',
                'details' => [$t[$key]->dateid]
              ]
            );
            array_push($links, ['from' => $t[$key]->docno, 'to' => $gjdata[$key2]->docno . $gjdata[$key2]->refx]);

            $qry = "select head.trno,head.docno,left(head.dateid,10) as dateid,
             CAST(concat('Total Amt: ',round(sum(stock.ext),2)) as CHAR) as rem
             from glhead as head 
             left join glstock as stock on stock.trno = head.trno
             where head.trno = ? 
             group by head.trno,head.docno,head.dateid";
            $stockdata = $this->coreFunctions->opentable($qry, [$t[$key]->refx]);
            $startyyy += 100;
            if (!empty($stockdata)) {
              foreach ($stockdata as $key1 => $value1) {
                data_set(
                  $nodes,
                  $stockdata[$key1]->docno,
                  [
                    'align' => 'right',
                    'x' => 200,
                    'y' => $startyyy - 100,
                    'w' => 250,
                    'h' => 80,
                    'type' => $stockdata[$key1]->docno,
                    'label' => $stockdata[$key1]->rem,
                    'color' => 'blue',
                    'details' => [$stockdata[$key1]->dateid]
                  ]
                );
                array_push($links, ['from' => $stockdata[$key1]->docno, 'to' => $t[$key]->docno]);
              }
            }
          }
        }
      }
    }



    $data['nodes'] = $nodes;
    $data['links'] = $links;

    return ['status' => true, 'msg' => 'Successfully fetched.', 'data' => $data];
  }

  public function reportsetup($config)
  {


    $txtfield = app($this->companysetup->getreportpath($config['params']))->createreportfilter($config);
    $txtdata = app($this->companysetup->getreportpath($config['params']))->reportparamsdata($config);

    $modulename = $this->modulename;
    $data = [];
    $style = 'width:500px;max-width:500px;';
    return ['status' => true, 'msg' => 'Loaded Success', 'modulename' => $modulename, 'data' => $data, 'txtfield' => $txtfield, 'txtdata' => $txtdata, 'style' => $style, 'directprint' => false];
  }

  public function reportdata($config)
  {

    $companyid = $config['params']['companyid'];

    if ($companyid == 40) { // cdo
      $dataparams = $config['params']['dataparams'];
      if (isset($dataparams['prepared'])) $this->othersClass->writeSignatories($config, 'prepared', $dataparams['prepared']);
      if (isset($dataparams['approved'])) $this->othersClass->writeSignatories($config, 'approved', $dataparams['approved']);
      if (isset($dataparams['received'])) $this->othersClass->writeSignatories($config, 'received', $dataparams['received']);
    }

    $data = app($this->companysetup->getreportpath($config['params']))->report_default_query($config);
    $str = app($this->companysetup->getreportpath($config['params']))->reportplotting($config, $data);

    return ['status' => true, 'msg' => 'Generating report successfully.', 'report' => $str];
  }
} //end class
