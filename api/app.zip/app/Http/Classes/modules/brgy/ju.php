<?php

namespace App\Http\Classes\modules\brgy;

use App\Http\Classes\builder\buttonClass;
use App\Http\Classes\builder\txtfieldClass;
use App\Http\Classes\builder\tabClass;
use App\Http\Classes\companysetup;
use App\Http\Classes\coreFunctions;
use App\Http\Classes\othersClass;
use App\Http\Classes\Logger;
use App\Http\Classes\SBCPDF;
use App\Http\Classes\lookup\hrislookup;

class ju
{

    private $btnClass;
    private $fieldClass;
    private $tabClass;
    public $modulename = 'COMPLAINTS FILE';
    public $gridname = 'inventory';
    private $companysetup;
    private $coreFunctions;
    private $othersClass;
    private $logger;
    public $expirystatus = ['readonly' => false, 'show' => true, 'showdate' => true];
    public $tablenum = 'transnum';
    public $head = 'juhead';
    public $hhead = 'hjuhead';
    public $stock = '';
    public $hstock = '';
    public $detail = '';
    public $hdetail = '';
    public $tablelogs = 'transnum_log';
    public $htablelogs = 'htransnum_log';
    public $tablelogs_del = 'del_transnum_log';

    private $fields = ['trno', 'docno',  'dateid', 'clientname',  'bstype', 'address', 'contact', 'ownername', 'owneraddr', 'orderno',  'ourref', 'crno', 'conaddr', 'creditinfo',  'petrno'];

    private $except = ['trno'];
    public $showfilteroption = true;
    public $showfilter = true;
    public $showcreatebtn = true;
    private $reporter;

    public function __construct($params = null)
    {
        $this->btnClass = new buttonClass;
        $this->fieldClass = new txtfieldClass($params);
        $this->tabClass = new tabClass($params);;
        $this->companysetup = new companysetup;
        $this->coreFunctions = new coreFunctions;
        $this->othersClass = new othersClass;
        $this->logger = new Logger;
        $this->reporter = new SBCPDF;
    }

    public function getAttrib()
    {
        $attrib = array(
            'load' => 5659,
            'view' => 5660,
            'edit' => 5661,
            'new' => 5662,
            'save' => 5663,
            'delete' => 5664,
            'print' => 5665,
            'lock' => 5666,
            'unlock' => 5667,
            'post' => 5668,
            'unpost' => 5669
        );

        return $attrib;
    }
    public function createHeadbutton($config)
    {
        $btns = array(
            'load',
            'new',
            'save',
            'delete',
            'cancel',
            'print',
            'post',
            'unpost',
            'lock',
            'unlock',
            'logs',
            'edit',
            'backlisting',
            'toggleup',
            'toggledown',
            'help',
            'others'
        );
        $buttons = $this->btnClass->create($btns);
        $buttons['others']['items'] = [
            'first' => ['label' => 'First', 'todo' => ['action' => 'navigation', 'lookupclass' => 'first', 'access' => 'view', 'type' => 'navigation']],
            'prev' => ['label' => 'Previous', 'todo' => ['action' => 'navigation', 'lookupclass' => 'prev', 'access' => 'view', 'type' => 'navigation']],
            'next' => ['label' => 'Next', 'todo' => ['action' => 'navigation', 'lookupclass' => 'next', 'access' => 'view', 'type' => 'navigation']],
            'last' => ['label' => 'Last', 'todo' => ['action' => 'navigation', 'lookupclass' => 'last', 'access' => 'view', 'type' => 'navigation']],
        ];
        return $buttons;
    }
    public function createHeadField($config)
    {
        $fields = ['docno', 'clientname', 'address', 'contact'];
        $col1 = $this->fieldClass->create($fields);
        data_set($col1, 'docno.label', 'Brgy Case#');
        data_set($col1, 'clientname.label', 'Complainant');
        data_set($col2, 'contact.label', 'Contact No.#');
        $fields = [['dateid', 'bstype'], 'ownername', 'owneraddr', 'orderno'];
        $col2 = $this->fieldClass->create($fields);

        data_set($col2, 'bstype.label', 'Time');
        data_set($col2, 'ownername.label', 'Respondent');
        data_set($col2, 'owneraddr.label', 'Address');
        data_set($col2, 'orderno.label', 'Contact');
        data_set($col2, 'orderno.type', 'input');


        $fields = ['ourref'];
        $col3 = $this->fieldClass->create($fields);
        data_set($col3, 'ourref.label', 'Entered By');
        return array('col1' => $col1, 'col2' => $col2, 'col3' => $col3);
    }
    public function loaddoclisting($config)
    {
        $itemfilter = $config['params']['itemfilter'];
        $doc = $config['params']['doc'];
        $center = $config['params']['center'];
        $condition = '';
        $searchfilter = $config['params']['search'];
        $filtersearch = "";
        switch ($itemfilter) {
            case 'draft':
                $condition = ' and num.postdate is null';
                break;
            case 'posted':
                $condition = ' and num.postdate is not null ';
                break;
        }
        $query = "
        select head.trno,head.docno,date_format(head.dateid,'%Y-%m-%d') as dateid,head.clientname,
        head.doc,head.createby, 'DRAFT' as status,ifnull(head.ownername,'') as planholder
        from juhead as head
        left join transnum as num on num.trno = head.trno
        where num.doc = '$doc' $condition
        union all
        select  head.trno,head.docno,date_format(head.dateid,'%Y-%m-%d') as dateid,head.clientname,
        head.doc,head.createby,'POSTED' as status,ifnull(head.ownername,'') as planholder
        from hjuhead as head
        left join transnum as num on num.trno = head.trno
        where num.doc = '$doc' $condition ";
        $data = $this->coreFunctions->opentable($query);
        return ['data' => $data, 'status' => true, 'msg' => 'Listing successfully loaded.'];
    }
    public function createTab($config)
    {
        $fields = ['crno', 'conaddr', 'creditinfo'];
        $col1 = $this->fieldClass->create($fields);
        data_set($col1, 'crno.label', 'FOR:');
        data_set($col1, 'crno.type', 'input');
        data_set($col1, 'conaddr.label', 'T.D.P.O:');
        data_set($col1, 'conaddr.type', 'textarea');
        data_set($col1, 'conaddr.class', 'csconaddr');
        data_set($col1, 'conaddr.style', 'height:10em');
        data_set($col1, 'conaddr.readonly', false);
        data_set($col1, 'creditinfo.label', 'FACTS:');
        data_set($col1, 'creditinfo.class', 'cscreditinfo');
        data_set($col1, 'creditinfo.readonly', false);
        $tab = [
            'multiinput1' => ['inputcolumn' => ['col1' => $col1,], 'label' => 'COMPLAINT']
        ];

        $tab['tableentry2'] = ['action' => 'tableentry', 'lookupclass' => 'casehistory', 'label' => 'CASE HISTORY'];
        $tab['tableentry'] = ['action' => 'documententry', 'lookupclass' => 'entrycntnumpicture', 'label' => 'Documents', 'access' => 'view'];
        $stockbuttons = [];
        $obj = $this->tabClass->createtab($tab, $stockbuttons);
        return $obj;
    }
    public function createtabbutton($config)
    {
        $tbuttons = [];
        $obj = $this->tabClass->createtabbutton($tbuttons);
        return $obj;
    }
    public function createdoclisting($config)
    {
        $getcols = ['action', 'liststatus', 'listdocument', 'listdate', 'listclientname', 'listplanholder'];
        foreach ($getcols as $key => $value) {
            $$value = $key;
        }
        $stockbuttons = ['view'];
        $cols = $this->tabClass->createdoclisting($getcols, $stockbuttons);
        $cols[$action]['style'] = 'width:40px;whiteSpace: normal;min-width:40px;';
        $cols[$liststatus]['style'] = 'width:80px;whiteSpace: normal;min-width:80px;';
        $cols[$listdocument]['label'] = 'Record No.';
        $cols[$listdocument]['style'] = 'width:150px;whiteSpace: normal;min-width:150px;';
        $cols[$listdate]['label'] = 'Date Complained';
        $cols[$listdate]['style'] = 'width:100px;whiteSpace: normal;min-width:100px;';
        $cols[$liststatus]['align'] = 'text-left';
        $cols[$listclientname]['label'] = 'Complainant';
        $cols[$listplanholder]['label'] = 'Respondent';
        return $cols;
    }
    public function loadheaddata($config)
    {
        $doc = $config['params']['doc'];
        $trno = $config['params']['trno'];
        $center = $config['params']['center'];
        $tablenum = $this->tablenum;

        $user = $config['params']['user'];
        if ($trno == 0) {
            $trno = $this->othersClass->readprofile('TRNO', $config);
            if ($trno == '') {
                $trno = $this->coreFunctions->datareader("select trno as value from " . $this->tablenum . " where doc=? and center=? order by trno desc limit 1", [$doc, $center]);
            }
            $config['params']['trno'] = $trno;
        } else {
            $this->othersClass->checkprofile('TRNO', $trno, $config);
        }
        $islocked = $this->othersClass->islocked($config);
        $isposted = $this->othersClass->isposted($config);
        $table = $this->head;
        $htable = $this->hhead;

        $qryselect = "
        select head.trno,head.docno, ifnull(head.clientname,'') as clientname, 
        ifnull(head.address,'') as address,ifnull(head.contact,'') as contact,head.dateid,
        ifnull(head.bstype,'') as bstype, ifnull(head.ownername,'') as ownername,
        ifnull(head.owneraddr,'') as owneraddr,ifnull(head.orderno,'') as orderno,
        ifnull(head.ourref,'') as ourref, ifnull(head.crno,'') as crno,ifnull(head.conaddr,'') as conaddr,
        ifnull(head.creditinfo,'') as creditinfo  ";

        $qry = $qryselect . " from $table as head
        left join $tablenum as num on num.trno = head.trno
        where num.doc = '$doc' and head.trno = ? 
        union all " . $qryselect . " from $htable as head
        left join $tablenum as num on num.trno = head.trno
        where num.doc = '$doc' and head.trno = ? ";

        $head = $this->coreFunctions->opentable($qry, [$trno, $trno]);
        if (!empty($head)) {
            $viewdate = $this->othersClass->getCurrentTimeStamp();
            $viewby = $config['params']['user'];
            $msg = 'Data Fetched Success';
            if (isset($config['msg'])) {
                $msg = $config['msg'];
            }
            $this->coreFunctions->sbcupdate($this->head, ['viewdate' => $viewdate, 'viewby' => $viewby], ['trno' => $trno]);
            return  ['head' => $head, 'griddata' => ['inventory' => []], 'islocked' => $islocked, 'isposted' => $isposted, 'isnew' => false, 'status' => true, 'msg' => $msg];
        } else {
            $head[0]['trno'] = 0;
            $head[0]['docno'] = '';
            return ['status' => false, 'isnew' => true, 'head' => $head, 'griddata' => ['inventory' => []], 'msg' => 'Data Head Fetched Failed'];
        }
    }
    public function createnewtransaction($docno, $params)
    {
        $data = [];
        $data[0]['trno'] = 0;
        $data[0]['docno'] = $docno;
        $data[0]['dateid'] = $this->othersClass->getCurrentDate();
        $data[0]['clientname'] = '';
        $data[0]['bstype'] = '';
        $data[0]['address'] = '';
        $data[0]['contact'] = '';
        $data[0]['ownername'] = '';
        $data[0]['owneraddr'] = '';
        $data[0]['orderno'] = '';
        $data[0]['ourref'] = '';
        $data[0]['crno'] = '';
        $data[0]['conaddr'] = '';
        $data[0]['creditinfo'] = '';

        $data[0]['petrno'] = 0;
        return $data;
    }
    public function updatehead($config, $isupdate)
    {
        $companyid = $config['params']['companyid'];
        $head = $config['params']['head'];
        $data = [];

        $dateTables = ['juhead'];
        $lookups = $this->othersClass->buildSanitizeLookups($config['params']['doc'], $companyid, [], false, $dateTables);

        if ($isupdate) {
            unset($this->fields['docno']);
        }

        foreach ($this->fields as $key) {
            if (array_key_exists($key, $head)) {
                $data[$key] = $head[$key];
                $data[$key] = $this->othersClass->sanitizekeyfieldFast($key, $data[$key], $lookups);
            }
        }
        if ($isupdate) {
            $data['editdate'] = $this->othersClass->getCurrentTimeStamp();
            $data['editby'] = $config['params']['user'];
            $this->coreFunctions->sbcupdate($this->head, $data, ['trno' => $head['trno']]);
        } else {
            $data['doc'] = $config['params']['doc'];
            $data['createdate'] = $this->othersClass->getCurrentTimeStamp();
            $data['createby'] = $config['params']['user'];
            $this->coreFunctions->sbcinsert($this->head, $data);
            $this->logger->sbcwritelog($head['trno'], $config, 'CREATE', $head['docno']);
        }
    }


    public function posttrans($config)
    {
        $trno = $config['params']['trno'];
        $user = $config['params']['user'];

        $docno = $this->coreFunctions->datareader('select docno as value from ' . $this->tablenum . ' where trno=?', [$trno]);

        if ($this->othersClass->isposted($config)) {
            return ['status' => false, 'msg' => 'Posting failed. Transaction has already been posted.'];
        }

        // Insert into hjuhead from juhead
        $qry = "insert into " . $this->hhead . "(trno, doc, docno, clientname, address, dateid, 
            bstype, contact, ownername, owneraddr, orderno, ourref, crno, conaddr, creditinfo, petrno,
            createdate, createby, editby, editdate, viewby, viewdate)
            SELECT trno, doc, docno, clientname, address, dateid, 
            bstype, contact, ownername, owneraddr, orderno, ourref, crno, conaddr, creditinfo, petrno,
            createdate, createby, editby, editdate, viewby, viewdate
            FROM " . $this->head . " where trno=? limit 1";

        $posthead = $this->coreFunctions->execqry($qry, 'insert', [$trno]);

        if ($posthead) {
            // Update transnum with postdate and postedby
            $date = $this->othersClass->getCurrentTimeStamp();
            $data = ['postdate' => $date, 'postedby' => $user];
            $this->coreFunctions->sbcupdate($this->tablenum, $data, ['trno' => $trno]);

            // Delete from juhead after successful posting
            $this->coreFunctions->execqry('delete from ' . $this->head . " where trno=?", "delete", [$trno]);

            // Write log
            $this->logger->sbcwritelog($trno, $config, 'POSTED', $docno);
            $this->othersClass->sbctransferlog($trno, $config, $this->htablelogs);

            return ['trno' => $trno, 'status' => true, 'msg' => 'Successfully posted.'];
        } else {
            return ['status' => false, 'msg' => 'Error posting complaint record.'];
        }
    } //end function

    public function unposttrans($config)
    {
        $trno = $config['params']['trno'];
        $user = $config['params']['user'];

        $docno = $this->coreFunctions->datareader('select docno as value from ' . $this->tablenum . ' where trno=?', [$trno]);

        // Insert from hjuhead back to juhead
        $qry = "insert into " . $this->head . "(trno, doc, docno, clientname, address, dateid, 
            bstype, contact, ownername, owneraddr, orderno, ourref, crno, conaddr, creditinfo, petrno,
            createdate, createby, editby, editdate, viewby, viewdate)
            SELECT trno, doc, docno, clientname, address, dateid, 
            bstype, contact, ownername, owneraddr, orderno, ourref, crno, conaddr, creditinfo, petrno,
            createdate, createby, editby, editdate, viewby, viewdate
            FROM " . $this->hhead . " where trno=? limit 1";

        if ($this->coreFunctions->execqry($qry, 'insert', [$trno])) {
            // Clear postdate from transnum
            $this->coreFunctions->execqry("update " . $this->tablenum . " set postdate=null, postedby='' where trno=?", 'update', [$trno]);

            // Delete from hjuhead after successful unposting
            $this->coreFunctions->execqry("delete from " . $this->hhead . " where trno=?", "delete", [$trno]);

            // Write log
            $this->logger->sbcwritelog($trno, $config, 'UNPOSTED', $docno);

            return ['trno' => $trno, 'status' => true, 'msg' => 'Successfully unposted.'];
        } else {
            return ['trno' => $trno, 'status' => false, 'msg' => 'UNPOST FAILED. Error restoring draft record.'];
        }
    } //end function

    public function deletetrans($config)
    {
        $trno = $config['params']['trno'];
        $doc = $config['params']['doc'];
        $table = $config['docmodule']->tablenum;
        $docno = $this->coreFunctions->datareader("select docno as value from " . $table . ' where trno=?', [$trno]);
        $qry = "select trno as value from " . $this->tablenum . " where doc=? and trno<? order by trno desc limit 1 ";
        $trno2 = $this->coreFunctions->datareader($qry, [$doc, $trno]);
        // $this->deleteallitem($config);
        $this->coreFunctions->execqry('delete from ' . $this->head . " where trno=?", 'delete', [$trno]);
        $this->coreFunctions->execqry('delete from ' . $this->tablenum . " where trno=?", 'delete', [$trno]);
        $this->logger->sbcdel_log($trno, $config, $docno);
        return ['trno' => $trno2, 'status' => true, 'msg' => 'Successfully deleted.'];
    } //end function


    public function reportsetup($config)
    {
        $trno = $config['params']['trno'];
        $doc = $config['params']['doc'];
        $txtfield = app($this->companysetup->getreportpath($config['params']))->createreportfilter($config);
        $txtdata = app($this->companysetup->getreportpath($config['params']))->reportparamsdata($config);
        $isposted = $this->othersClass->isposted($config);
        $head = 'hjuhead';
        if (!$isposted) {
            $head = 'juhead';
        }

        $data2 = $this->coreFunctions->datareader("select petrno as value from " . $head . ' where doc=? and trno=?', [$doc, $trno]);
        $printcount = isset($data2) ? $data2 : 0;

        $date = $this->othersClass->getCurrentDate();
        $printcount++;

        $ctnsno = 'SUMMONS ' . $printcount;

        if ($printcount == 1) {
            $bpo = 'SUMMONS / OFFICER\'S RETURN';
        } elseif ($printcount == 2) {
            $bpo = 'NOTICE OF HEARING';
        } elseif ($printcount == 3) {
            $bpo = 'SOMMUNS PRINTOUT';
        }

        $updatehead = $this->coreFunctions->sbcupdate($head, ['petrno' => $printcount], ['trno' => $trno]);
        if ($printcount <= 3) {
            if ($updatehead) {
                $datahere = [
                    'category' =>  $ctnsno,
                    'reqtype' => $bpo,
                    'encodeddate' => $date,
                    'jutrno' => $trno
                ];
                $req = $this->coreFunctions->insertGetId('reqcategory', $datahere);
            }
        }


        $modulename = $this->modulename;
        $data = [];
        $style = 'width:500px;max-width:500px;';
        return ['status' => true, 'msg' => 'Loaded Success', 'modulename' => $modulename, 'data' => $data, 'txtfield' => $txtfield, 'txtdata' => $txtdata, 'style' => $style, 'directprint' => false];
    }

    public function reportdata($config)
    {
        $this->logger->sbcviewreportlog($config);

        $data = app($this->companysetup->getreportpath($config['params']))->generateResult($config);
        $str = app($this->companysetup->getreportpath($config['params']))->reportplotting($config, $data);

        return ['status' => true, 'msg' => 'Generating report successfully.', 'report' => $str];
    }
}
